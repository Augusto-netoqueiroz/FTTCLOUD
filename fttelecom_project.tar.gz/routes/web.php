<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Aqui é onde você pode registrar rotas web para sua aplicação.  Estas
| rotas são carregadas pelo RouteServiceProvider e todas elas
| recebem o grupo de middleware "web".  Você pode criar páginas
| ou redirecionar para o frontend SPA conforme necessário.
*/

Route::get('/', function () {
    return response()->json(['message' => 'Bem‑vindo ao SaaS FTTelecom']);
});