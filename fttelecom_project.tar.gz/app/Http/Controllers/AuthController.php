<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Tenant;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{
    /**
     * Registra um novo tenant e o usuário administrador inicial.
     * Este endpoint deve ser chamado sem subdomínio ou com subdomínio genérico,
     * pois criará uma nova entrada na tabela `tenants` e associará o
     * primeiro usuário a ela.
     */
    public function registerTenant(Request $request)
    {
        $data = $request->validate([
            'tenant_name' => 'required|string|max:255',
            'subdomain'   => 'required|string|alpha_dash|max:255|unique:tenants,subdomain',
            'name'        => 'required|string|max:255',
            'email'       => 'required|string|email|max:255|unique:users,email',
            'password'    => 'required|string|min:8|confirmed',
        ]);

        // Cria o tenant
        $tenant = Tenant::create([
            'name'      => $data['tenant_name'],
            'subdomain' => strtolower($data['subdomain']),
            'database'  => null, // utilizar se quiser armazenar em banco dedicado
        ]);

        // Cria o usuário administrador do tenant
        $user = User::create([
            'tenant_id' => $tenant->id,
            'name'      => $data['name'],
            'email'     => $data['email'],
            'password'  => Hash::make($data['password']),
        ]);

        $token = $user->createToken('auth_token')->plainTextToken;

        return response()->json([
            'tenant' => $tenant,
            'user'   => $user,
            'token'  => $token,
        ], 201);
    }

    /**
     * Registra um usuário adicional para o tenant atual.  O tenant deve
     * estar resolvido pelo middleware; somente usuários existentes com
     * permissão adequada devem chamar este endpoint.
     */
    public function registerUser(Request $request)
    {
        $tenant = app('tenant');
        if (!$tenant) {
            return response()->json(['message' => 'Tenant não resolvido'], 400);
        }

        $data = $request->validate([
            'name'     => 'required|string|max:255',
            'email'    => 'required|string|email|max:255|unique:users,email',
            'password' => 'required|string|min:8|confirmed',
        ]);

        $user = User::create([
            'tenant_id' => $tenant->id,
            'name'      => $data['name'],
            'email'     => $data['email'],
            'password'  => Hash::make($data['password']),
        ]);

        return response()->json($user, 201);
    }

    /**
     * Realiza login de um usuário retornando um token do Sanctum.
     */
    public function login(Request $request)
    {
        $tenant = app('tenant');
        if (!$tenant) {
            return response()->json(['message' => 'Tenant não resolvido'], 400);
        }

        $data = $request->validate([
            'email'    => 'required|string|email',
            'password' => 'required|string',
        ]);

        $user = User::where('email', $data['email'])->first();
        if (!$user || !Hash::check($data['password'], $user->password)) {
            throw ValidationException::withMessages([
                'email' => ['As credenciais informadas estão incorretas.'],
            ]);
        }

        // Assegure que o usuário pertence ao tenant atual
        if ($user->tenant_id !== $tenant->id) {
            return response()->json(['message' => 'Usuário não pertence a este tenant'], 403);
        }

        $token = $user->createToken('auth_token')->plainTextToken;

        return response()->json([
            'user'  => $user,
            'token' => $token,
        ]);
    }

    /**
     * Realiza logout do usuário atual revogando o token.
     */
    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();
        return response()->json(['message' => 'Logout realizado com sucesso']);
    }
}