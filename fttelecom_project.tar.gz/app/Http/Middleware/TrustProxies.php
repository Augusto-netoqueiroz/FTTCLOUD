<?php

namespace App\Http\Middleware;

use Illuminate\Http\Request;
use Illuminate\Http\Middleware\TrustProxies as Middleware;

/**
 * Middleware para tratar proxies confiáveis.
 */
class TrustProxies extends Middleware
{
    /**
     * Os proxies ou redes que devem ser confiáveis.
     *
     * @var array<int, string>|string|null
     */
    protected $proxies = '*';

    /**
     * Os cabeçalhos que devem ser usados para detectar proxies.
     *
     * @var int
     */
    protected $headers = Request::HEADER_X_FORWARDED_ALL;
}