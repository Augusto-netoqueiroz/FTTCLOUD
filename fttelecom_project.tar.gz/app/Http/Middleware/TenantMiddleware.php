<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use App\Models\Tenant;

/**
 * TenantMiddleware
 *
 * Resolve o tenant com base no subdomínio presente no host da
 * requisição.  Se o tenant não for encontrado, lança um 404.
 * O tenant encontrado é registrado na aplicação (`app('tenant')`) para
 * que modelos com o trait HasTenantScope possam filtrar suas queries.
 */
class TenantMiddleware
{
    /**
     * Manipula uma requisição entrando na aplicação.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        $host = $request->getHost();
        // Obtém apenas a primeira parte antes do primeiro ponto
        $parts = explode('.', $host);
        $subdomain = array_shift($parts);

        // Ignora www e dominios sem subdomínio
        if ($subdomain === 'www' || empty($subdomain)) {
            throw new NotFoundHttpException('Tenant não encontrado');
        }

        $tenant = Tenant::where('subdomain', $subdomain)->first();
        if (!$tenant) {
            throw new NotFoundHttpException('Tenant não encontrado');
        }

        // Registra o tenant resolvido na aplicação
        app()->instance('tenant', $tenant);

        return $next($request);
    }
}