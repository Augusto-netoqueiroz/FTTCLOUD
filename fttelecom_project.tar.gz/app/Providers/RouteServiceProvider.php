<?php

namespace App\Providers;

use Illuminate\Foundation\Support\Providers\RouteServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Route;

/**
 * RouteServiceProvider
 *
 * Responsável por agrupar e carregar as rotas da aplicação.  Aqui
 * definimos grupos para rotas web, API e rotas específicas de tenant.
 */
class RouteServiceProvider extends ServiceProvider
{
    /**
     * Define o namespace base para os controladores.  Em projetos
     * modernos do Laravel, o namespace dos controladores é
     * automaticamente deduzido, portanto esta propriedade pode
     * permanecer nula.
     */
    protected $namespace = null;

    /**
     * Carrega as rotas da aplicação.
     */
    public function boot(): void
    {
        parent::boot();
    }

    /**
     * Define as rotas que serão mapeadas para a aplicação.
     */
    public function map(): void
    {
        $this->mapApiRoutes();
        $this->mapTenantRoutes();
        $this->mapWebRoutes();
    }

    /**
     * Define as rotas da API.
     */
    protected function mapApiRoutes(): void
    {
        Route::prefix('api')
            ->middleware('api')
            ->group(base_path('routes/api.php'));
    }

    /**
     * Define rotas específicas para tenants (caso queira separá‑las).
     */
    protected function mapTenantRoutes(): void
    {
        Route::prefix('api')
            ->middleware(['api', 'tenant'])
            ->group(base_path('routes/tenant.php'));
    }

    /**
     * Define as rotas web.
     */
    protected function mapWebRoutes(): void
    {
        Route::middleware('web')
            ->group(base_path('routes/web.php'));
    }
}