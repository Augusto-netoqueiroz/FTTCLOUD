<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

/**
 * AppServiceProvider
 *
 * Responsável por registrar e inicializar serviços genéricos da aplicação.
 */
class AppServiceProvider extends ServiceProvider
{
    /**
     * Registra bindings no container.
     */
    public function register(): void
    {
        // Serviços globais podem ser registrados aqui
    }

    /**
     * Inicializa qualquer bootstrapping necessário.
     */
    public function boot(): void
    {
        // Pode ser utilizado para estender validações, macros, etc.
    }
}